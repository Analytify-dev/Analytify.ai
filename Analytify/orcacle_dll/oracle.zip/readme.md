## Lets Setup Supportive Files for Oracle DB

Check for Python Path
``` ...\Programs\Python\PythonXXX ```

Copy all the .dll Present in oracle_dll Folder into Above Python Path in OS.